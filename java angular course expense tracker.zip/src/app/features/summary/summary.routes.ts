import { Routes } from '@angular/router';
import { SummaryDashboardComponent } from './components/summary-dashboard/summary-dashboard.component';

export const routes: Routes = [
  {
    path: '',
    component: SummaryDashboardComponent,
  },
];