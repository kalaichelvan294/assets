import { Injectable, inject } from '@angular/core';
import { Observable } from 'rxjs';
import { map } from 'rxjs/operators';

import { Expense } from '../../../shared/models/expense.model';
import { ExpenseService } from '../../expenses/services/expense.service';

@Injectable({
  providedIn: 'root'
})
export class SummaryService {
  // This service will handle data for the summary dashboard.
  private expenseService = inject(ExpenseService);

  getMonthlySummary(): Observable<{ month: string, total: number }[]> {
    return this.expenseService.getExpenses().pipe(
      map((expenses: Expense[]) => {
        const monthlySummaryMap = new Map<string, number>();
        expenses.forEach((expense: Expense) => {
          const month = new Date(expense.date).toISOString().substring(0, 7);
          const currentTotal = monthlySummaryMap.get(month) || 0;
          monthlySummaryMap.set(month, currentTotal + expense.amount);
        });
        return Array.from(monthlySummaryMap.entries()).map(([month, total]) => ({ month, total }));
      })
    );
  }

  getCategorySummary(): Observable<{ category: string, total: number }[]> {
    return this.expenseService.getExpenses().pipe(
      map((expenses: Expense[]) => {
        const categorySummaryMap = new Map<string, number>();
        expenses.forEach((expense: Expense) => {
          const currentTotal = categorySummaryMap.get(expense.category) || 0;
          categorySummaryMap.set(expense.category, currentTotal + expense.amount);
        });
        return Array.from(categorySummaryMap.entries()).map(([category, total]) => ({ category, total }));
      })
    );
  }
}
