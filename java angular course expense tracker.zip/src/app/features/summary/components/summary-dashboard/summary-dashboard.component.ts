import { Component, ChangeDetectionStrategy, OnInit } from '@angular/core';
import { CommonModule } from '@angular/common';

import { MatCardModule } from '@angular/material/card';
import { MatIconModule } from '@angular/material/icon';
import { MatButtonModule } from '@angular/material/button';
import { MatProgressBarModule } from '@angular/material/progress-bar';

@Component({
  selector: 'app-summary-dashboard',
  standalone: true,
  imports: [CommonModule, MatCardModule, MatIconModule, MatButtonModule, MatProgressBarModule],
  templateUrl: './summary-dashboard.component.html',
  styleUrls: ['./summary-dashboard.component.css'],
  changeDetection: ChangeDetectionStrategy.OnPush,
})
export class SummaryDashboardComponent implements OnInit {

  // Summary Statistics
  totalExpenses = 45750;
  monthlyAverage = 15250;
  totalTransactions = 127;
  highestExpense = 8500;

  // Monthly Budget
  monthlyBudget = 20000;
  budgetUsed = 15250;
  budgetRemaining = 4750;
  budgetUsedPercentage = 76;

  // Category Data with dummy values
  categoryData = [
    { name: 'Food & Dining', amount: 12500, percentage: 27, icon: 'restaurant', color: '#FF6B6B' },
    { name: 'Transportation', amount: 8750, percentage: 19, icon: 'directions_car', color: '#4ECDC4' },
    { name: 'Shopping', amount: 7200, percentage: 16, icon: 'shopping_cart', color: '#45B7D1' },
    { name: 'Utilities', amount: 6800, percentage: 15, icon: 'electrical_services', color: '#96CEB4' },
    { name: 'Entertainment', amount: 5250, percentage: 11, icon: 'movie', color: '#FFEAA7' },
    { name: 'Healthcare', amount: 3200, percentage: 7, icon: 'local_hospital', color: '#DDA0DD' },
    { name: 'Travel', amount: 2050, percentage: 5, icon: 'flight', color: '#98D8C8' }
  ];

  // Monthly Trends
  monthlyTrends = [
    { month: 'Jan', amount: 18500, transactions: 42 },
    { month: 'Feb', amount: 16200, transactions: 38 },
    { month: 'Mar', amount: 19800, transactions: 45 },
    { month: 'Apr', amount: 15250, transactions: 35 },
    { month: 'May', amount: 21300, transactions: 48 },
    { month: 'Jun', amount: 17900, transactions: 41 }
  ];

  // Recent Insights
  insights = [
    { type: 'warning', message: 'Food expenses increased by 15% this month', icon: 'trending_up' },
    { type: 'success', message: 'You saved ₹2,500 on transportation', icon: 'savings' },
    { type: 'info', message: 'Average transaction amount: ₹360', icon: 'analytics' },
    { type: 'tip', message: 'Consider setting a budget for entertainment', icon: 'lightbulb' }
  ];

  // Top Spending Days
  topSpendingDays = [
    { day: 'Monday', amount: 2850, percentage: 18 },
    { day: 'Friday', amount: 2650, percentage: 17 },
    { day: 'Saturday', amount: 2400, percentage: 15 },
    { day: 'Sunday', amount: 2100, percentage: 13 }
  ];

  ngOnInit(): void {
    this.calculateDerivedMetrics();
  }

  private calculateDerivedMetrics(): void {
    // Calculate budget usage percentage
    this.budgetUsedPercentage = Math.round((this.budgetUsed / this.monthlyBudget) * 100);
    this.budgetRemaining = this.monthlyBudget - this.budgetUsed;
  }

  getBudgetStatus(): string {
    if (this.budgetUsedPercentage >= 90) return 'danger';
    if (this.budgetUsedPercentage >= 75) return 'warning';
    return 'success';
  }

  getInsightClass(type: string): string {
    const classes = {
      'warning': 'insight-warning',
      'success': 'insight-success',
      'info': 'insight-info',
      'tip': 'insight-tip'
    };
    return classes[type as keyof typeof classes] || 'insight-info';
  }

  exportToCsv(): void {
    console.log('Exporting expense data to CSV...');
    // In a real application, you would create and download a CSV file here
  }

  exportToPdf(): void {
    console.log('Exporting expense report to PDF...');
    // In a real application, you would generate and download a PDF report here
  }

  viewDetailedReport(): void {
    console.log('Opening detailed expense report...');
    // Navigate to detailed report page
  }
}
