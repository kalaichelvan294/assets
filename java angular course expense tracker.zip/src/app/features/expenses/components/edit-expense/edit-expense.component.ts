import { Component, ChangeDetectionStrategy, inject, OnInit, Inject } from '@angular/core';
import { FormBuilder, FormGroup, Validators, ReactiveFormsModule } from '@angular/forms';
import { CommonModule } from '@angular/common';
import { MAT_DIALOG_DATA, MatDialogRef, MatDialogModule } from '@angular/material/dialog';

import { MatInputModule } from '@angular/material/input';
import { MatButtonModule } from '@angular/material/button';
import { MatFormFieldModule } from '@angular/material/form-field';
import { MatIconModule } from '@angular/material/icon';

import { ExpenseService } from '../../services/expense.service';
import { Expense } from '../../../../shared/models/expense.model';
import { NotificationService } from '../../../../shared/services/notification.service';

@Component({
  selector: 'app-edit-expense',
  templateUrl: './edit-expense.component.html',
  styleUrls: ['./edit-expense.component.css'],
  changeDetection: ChangeDetectionStrategy.OnPush,
  standalone: true,
  imports: [
    ReactiveFormsModule,
    CommonModule,
    MatInputModule,
    MatButtonModule,
    MatFormFieldModule,
    MatIconModule,
    MatDialogModule
  ]

})
export class EditExpenseComponent implements OnInit {
  private fb = inject(FormBuilder);
  private expenseService = inject(ExpenseService);
  private notificationService = inject(NotificationService);
  private dialogRef = inject(MatDialogRef<EditExpenseComponent>);

  expenseForm!: FormGroup;

  constructor(@Inject(MAT_DIALOG_DATA) public expense: Expense) {}

  ngOnInit(): void {
    this.expenseForm = this.fb.group({
      description: [this.expense.description, [Validators.required, Validators.maxLength(100)]],
      amount: [this.expense.amount, [Validators.required, Validators.min(0.01)]],
      date: [this.expense.date, Validators.required],
      category: [this.expense.category, Validators.required]
    });
  }

  onSubmit(): void {
    if (this.expenseForm.valid) {
      const updatedExpense: Expense = {
        id: this.expense.id,
        ...this.expenseForm.value
      };

      this.expenseService.updateExpense(updatedExpense).subscribe({
        next: () => {
          this.notificationService.showSuccess('Expense updated successfully!');
          this.dialogRef.close(true);
        },
        error: (error) => {
          console.error('Error updating expense:', error);
          this.notificationService.showError('Failed to update expense. Please try again.');
        }
      });
    } else {
      this.markFormGroupTouched();
    }
  }

  onCancel(): void {
    this.dialogRef.close(false);
  }

  private markFormGroupTouched(): void {
    Object.keys(this.expenseForm.controls).forEach(key => {
      const control = this.expenseForm.get(key);
      control?.markAsTouched();
    });
  }
}
