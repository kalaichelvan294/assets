import { Component, ChangeDetectionStrategy, inject, OnInit } from '@angular/core';
import { CommonModule } from '@angular/common';
import { Observable, BehaviorSubject, combineLatest, of } from 'rxjs';
import { tap, debounceTime, distinctUntilChanged, map, startWith } from 'rxjs/operators';

import { MatCardModule } from '@angular/material/card';
import { MatButtonModule } from '@angular/material/button';
import { MatDialog, MatDialogModule } from '@angular/material/dialog';
import { MatFormFieldModule } from '@angular/material/form-field';
import { MatInputModule } from '@angular/material/input';
import { MatIconModule } from '@angular/material/icon';
import { MatSelectModule } from '@angular/material/select';
import { MatButtonToggleModule } from '@angular/material/button-toggle';
import { MatTooltipModule } from '@angular/material/tooltip';

import { ExpenseService } from './../../services/expense.service';
import { AddExpenseComponent } from './../add-expense/add-expense.component';
import { EditExpenseComponent } from './../edit-expense/edit-expense.component';
import { Expense } from '../../../../shared/models/expense.model';
import { HighlightDirective } from "../../../../shared/directives/highlight.directive";
import { ConfirmationDialogComponent, ConfirmationDialogData } from '../../../../shared/components/confirmation-dialog/confirmation-dialog.component';
import { LoadingSpinnerComponent } from '../../../../shared/components/loading-spinner/loading-spinner.component';
import { NotificationService } from '../../../../shared/services/notification.service';


@Component({
  selector: 'app-expense-list',
  standalone: true,
  imports: [
    CommonModule,
    HighlightDirective,
    MatCardModule,
    MatButtonToggleModule,
    MatDialogModule,
    MatButtonModule,
    MatFormFieldModule,
    MatInputModule,
    MatIconModule,
    MatSelectModule,
    MatTooltipModule,
    LoadingSpinnerComponent
  ],
  templateUrl: './expense-list.component.html',
  styleUrls: ['./expense-list.component.css'],
  changeDetection: ChangeDetectionStrategy.OnPush,
})
export class ExpenseListComponent implements OnInit {
  private expenseService = inject(ExpenseService);
  private dialog = inject(MatDialog);
  private notificationService = inject(NotificationService);

  private categoryFilterSubject = new BehaviorSubject<string>('');
  private searchTermSubject = new BehaviorSubject<string>('');
  private currentPageSubject = new BehaviorSubject<number>(1);
  private itemsPerPageSubject = new BehaviorSubject<number>(10);
  private sortCriteriaSubject = new BehaviorSubject<string>('date');
  private sortDirectionSubject = new BehaviorSubject<string>('desc');
  private currentDialogRef: any;

  expenses$!: Observable<Expense[]>;
  currentPage!: number;
  isLoading = false;

  ngOnInit(): void {
    this.expenses$ = combineLatest([
      this.expenseService.getExpenses(),
      this.categoryFilterSubject.pipe(startWith('')),
      this.searchTermSubject.pipe(debounceTime(300), distinctUntilChanged(), startWith('')),
      this.currentPageSubject,
      this.itemsPerPageSubject,
      this.sortCriteriaSubject,
      this.sortDirectionSubject
    ]).pipe(
      map(([expenses, categoryFilter, searchTerm, currentPage, itemsPerPage, sortCriteria, sortDirection]) => {
        // Apply filtering
        let filteredExpenses = expenses.filter((expense: Expense) =>
          expense.category.toLowerCase().includes(categoryFilter.toLowerCase()) &&
          expense.description.toLowerCase().includes(searchTerm.toLowerCase())
        );

        // Apply sorting
        filteredExpenses.sort((a: Expense, b: Expense) => {
          const valueA = (a as any)[sortCriteria];
          const valueB = (b as any)[sortCriteria];

          if (valueA < valueB) return sortDirection === 'asc' ? -1 : 1;
          if (valueA > valueB) return sortDirection === 'asc' ? 1 : -1;
          return 0;
        });

        // Apply pagination
        const startIndex = (currentPage - 1) * itemsPerPage;
        const endIndex = startIndex + itemsPerPage;
        return filteredExpenses.slice(startIndex, endIndex);
      }),
      tap(() => this.currentPage = this.currentPageSubject.value)
    );
  }


  deleteExpense(expense: Expense): void {
    const dialogData: ConfirmationDialogData = {
      title: 'Delete Expense',
      message: `Are you sure you want to delete "${expense.description}"? This action cannot be undone.`,
      confirmText: 'Delete',
      cancelText: 'Cancel',
      icon: 'delete',
      color: 'warn'
    };

    const dialogRef = this.dialog.open(ConfirmationDialogComponent, {
      width: '400px',
      data: dialogData
    });

    dialogRef.afterClosed().subscribe(result => {
      if (result && expense.id) {
        this.performDelete(expense.id);
      }
    });
  }

  private performDelete(id: string): void {
    this.isLoading = true;

    // Optimistically update the UI
    let currentExpenses: Expense[] = [];
    const subscription = this.expenses$.subscribe(exp => currentExpenses = exp);
    subscription.unsubscribe();
    this.expenses$ = of(currentExpenses.filter(expense => expense.id !== id));

    this.expenseService.deleteExpense(id).pipe(
      tap(() => {
        this.isLoading = false;
      })
    ).subscribe({
      next: () => {
        this.notificationService.showSuccess('Expense deleted successfully');
      },
      error: (error) => {
        console.error('Error deleting expense:', error);
        this.isLoading = false;
        this.notificationService.showError('Failed to delete expense. Please try again.');
        // Revert the optimistic update by refreshing the data
        this.refreshExpenses();
      }
    });
  }

  openAddExpenseModal(): void {
    this.currentDialogRef = this.dialog.open(AddExpenseComponent, {
      width: '650px',
      maxWidth: '90vw'
    });

    this.currentDialogRef.afterClosed().subscribe(() => {
      this.refreshExpenses();
    });
  }

  openEditExpenseModal(expense: Expense): void {
    this.currentDialogRef = this.dialog.open(EditExpenseComponent, {
      width: '650px',
      maxWidth: '90vw',
      data: expense
    });

    this.currentDialogRef.afterClosed().subscribe(() => {
      this.refreshExpenses();
    });
  }

  nextPage(): void {
    const currentPage = this.currentPageSubject.value;
    this.currentPageSubject.next(currentPage + 1);
  }

  prevPage(): void {
    if (this.currentPageSubject.value > 1) {
      const currentPage = this.currentPageSubject.value;
      this.currentPageSubject.next(currentPage - 1);
    }
  }

  onSortCriteriaChange(value: string): void {
    this.sortCriteriaSubject.next(value);
    this.currentPageSubject.next(1);
  }

  onSortDirectionChange(direction: 'asc' | 'desc'): void {
    this.sortDirectionSubject.next(direction);
    this.currentPageSubject.next(1);
  }

  onCategoryFilterChange(event: Event): void {
    const value = (event.target as HTMLInputElement).value;
    this.categoryFilterSubject.next(value);
    this.currentPageSubject.next(1);
  }

  onSearchChange(event: Event): void {
    const value = (event.target as HTMLInputElement).value;
    this.searchTermSubject.next(value);
    this.currentPageSubject.next(1);
  }

  private refreshExpenses(): void {
    // Re-initialize the expenses observable to refresh data
    this.ngOnInit();
  }
}
