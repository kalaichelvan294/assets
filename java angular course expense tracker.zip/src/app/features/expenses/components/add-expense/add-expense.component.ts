import { Component, ChangeDetectionStrategy, inject, OnInit, Output, EventEmitter, ChangeDetectorRef } from '@angular/core';
import { FormBuilder, FormGroup, Validators, ReactiveFormsModule } from '@angular/forms';
import { CommonModule } from '@angular/common';
import { finalize } from 'rxjs/operators';

import { MatFormFieldModule } from '@angular/material/form-field';
import { MatInputModule } from '@angular/material/input';
import { MatDatepickerModule } from '@angular/material/datepicker';
import { MatNativeDateModule } from '@angular/material/core';
import { MatSelectModule } from '@angular/material/select';
import { MatButtonModule } from '@angular/material/button';
import { MatIconModule } from "@angular/material/icon";
import { MatDialogModule } from '@angular/material/dialog';

import { ExpenseService } from '../../services/expense.service';
import { Expense } from '../../../../shared/models/expense.model';
import { NotificationService } from '../../../../shared/services/notification.service';

@Component({
  selector: 'app-add-expense',
  templateUrl: './add-expense.component.html',
  styleUrls: ['./add-expense.component.css'],
  changeDetection: ChangeDetectionStrategy.OnPush,
  standalone: true,
  imports: [
    ReactiveFormsModule,
    CommonModule,
    MatFormFieldModule,
    MatInputModule,
    MatDatepickerModule,
    MatNativeDateModule,
    MatSelectModule,
    MatButtonModule,
    MatIconModule,
    MatDialogModule
  ],
})
export class AddExpenseComponent implements OnInit {
  private fb = inject(FormBuilder);
  private expenseService = inject(ExpenseService);
  private cdr = inject(ChangeDetectorRef);
  private notificationService = inject(NotificationService);

  @Output() expenseAdded = new EventEmitter<void>();

  expenseForm!: FormGroup;
  isSubmitting = false;

  ngOnInit(): void {
    this.expenseForm = this.fb.group({
      description: ['', [Validators.required, Validators.maxLength(100)]],
      amount: [null, [Validators.required, Validators.min(0.01)]],
      date: [new Date(), Validators.required],
      category: ['', Validators.required]
    });
  }

  onSubmit(): void {
    if (this.expenseForm.valid && !this.isSubmitting) {
      this.isSubmitting = true;
      this.cdr.markForCheck();

      // Format the date properly
      const formValue = { ...this.expenseForm.value };
      if (formValue.date instanceof Date) {
        formValue.date = formValue.date.toISOString().split('T')[0];
      }

      this.expenseService.addExpense(formValue as Omit<Expense, 'id'>)
        .pipe(
          finalize(() => {
            this.isSubmitting = false;
            this.cdr.markForCheck();
          })
        )
        .subscribe({
          next: () => {
            this.notificationService.showSuccess('Expense added successfully!');
            this.expenseAdded.emit();
            this.resetForm();
          },
          error: (error) => {
            console.error('Error adding expense:', error);
            this.notificationService.showError('Failed to add expense. Please try again.');
          }
        });
    } else {
      // Mark all fields as touched to show validation errors
      this.markFormGroupTouched();
    }
  }

  private resetForm(): void {
    this.expenseForm.reset({
      description: '',
      amount: null,
      date: new Date(),
      category: ''
    });
  }

  private markFormGroupTouched(): void {
    Object.keys(this.expenseForm.controls).forEach(key => {
      const control = this.expenseForm.get(key);
      control?.markAsTouched();
    });
  }
}
