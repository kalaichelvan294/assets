import { Injectable } from '@angular/core';
import { Observable, of } from 'rxjs';
import { Expense } from '../../../shared/models/expense.model';

@Injectable({ 
  providedIn: 'root'
})
export class ExpenseService {
  // This service will handle mock expense data.
  private expenses: Expense[] = [
    { id: '1', description: 'Groceries', amount: 55.50, date: '2023-10-26', category: 'Food' },
    { id: '2', description: 'Bus Ticket', amount: 3.00, date: '2023-10-26', category: 'Travel' },
    { id: '3', description: 'Electricity Bill', amount: 120.00, date: '2023-10-25', category: 'Utilities' },
    { id: '4', description: 'Lunch', amount: 15.75, date: '2023-10-25', category: 'Food' },
    { id: '5', description: 'Gas', amount: 40.00, date: '2023-10-24', category: 'Transport' }
  ];

  constructor() { }

  getExpenses(): Observable<Expense[]> { 
    return of(this.expenses);
  }

  addExpense(expense: Omit<Expense, 'id'>): Observable<Expense> {
    const newExpense: Expense = {
      ...expense,
      id: Date.now().toString() // Simple unique ID generation
    };
    this.expenses.push(newExpense);
    return of(newExpense);
  }

  updateExpense(expense: Expense): Observable<Expense | undefined> {
    const index = this.expenses.findIndex(e => e.id === expense.id);
    if (index > -1) {
      this.expenses[index] = expense;
      return of(expense);
    }
    return of(undefined);
  }

  deleteExpense(id: string): Observable<boolean> {
    const initialLength = this.expenses.length;
    this.expenses = this.expenses.filter(expense => expense.id !== id);
    return of(this.expenses.length < initialLength);
  }
}