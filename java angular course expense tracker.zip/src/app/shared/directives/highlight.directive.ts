import { Directive, ElementRef, inject, Input, OnChanges, SimpleChanges } from '@angular/core';

@Directive({
  selector: '[appHighlightValue]',
  standalone: true
})
export class HighlightDirective implements OnChanges {
  private el = inject(ElementRef);
  @Input() appHighlightValue!: number;

  ngOnChanges(changes: SimpleChanges): void {
    const highlightThreshold = 10000; // Threshold for INR (₹10,000)
    if (changes['appHighlightValue'] && this.appHighlightValue > highlightThreshold) {
      this.el.nativeElement.style.backgroundColor = 'rgba(255, 193, 7, 0.2)'; // Apply subtle yellow highlight
      this.el.nativeElement.style.border = '1px solid rgba(255, 193, 7, 0.5)';
    } else {
      this.el.nativeElement.style.backgroundColor = ''; // Remove highlight
      this.el.nativeElement.style.border = '';
    }
  }

}
