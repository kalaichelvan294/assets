import { Routes } from '@angular/router';

export const routes: Routes = [
  {
    path: 'expenses',
    loadChildren: () => import('./features/expenses/expenses.routes').then(m => m.routes)
  },
  {
    path: 'summary',
    loadChildren: () => import('./features/summary/summary.routes').then(m => m.routes)
  },
  {
    path: '',
    redirectTo: 'expenses',
    pathMatch: 'full'
  }
];
