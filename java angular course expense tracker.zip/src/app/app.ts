import { Component, signal } from '@angular/core';
import { FormControl, FormGroup, ReactiveFormsModule } from '@angular/forms';
import { RouterOutlet } from '@angular/router';

@Component({
  selector: 'app-root',
  imports: [RouterOutlet,ReactiveFormsModule],
  templateUrl: './app.html',
  styleUrl: './app.css',
})
export class App {
  protected readonly title = signal('myapp');

  testFormGroup = new FormGroup({
    sss: new FormControl<string>(''),
  });

  constructor() {
    this.testFormGroup.valueChanges
      .subscribe((val) => {
        console.log(val);
      });
  }
}
